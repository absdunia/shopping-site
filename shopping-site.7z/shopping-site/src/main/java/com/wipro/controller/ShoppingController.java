package com.wipro.controller;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wipro.service.ProductService;

@Controller
public class ShoppingController {
	 @PersistenceContext
	 EntityManager entityManager;
	
	@Autowired
    private ProductService productService;

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String home(ModelMap map) {
		map.addAttribute("product", productService.getAllUsers());
		return "home";
	}
}
