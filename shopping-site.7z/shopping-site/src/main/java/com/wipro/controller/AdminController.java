package com.wipro.controller;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.wipro.model.Product;
import com.wipro.model.SiteName;
import com.wipro.service.ProductService;

@Controller
@SessionAttributes("siteName")
public class AdminController {
	 @PersistenceContext
	 EntityManager entityManager;
	
	@Autowired
    private ProductService productService;
	private SiteName siteName;
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/adminDashboard", method = RequestMethod.GET)
	public String home(ModelMap map) {
		map.addAttribute("product", productService.getAllUsers());
		return "AdminDashboard";
	}
	
	@RequestMapping(value = "/adminAddItem", method = RequestMethod.GET)
	public String AddItem(ModelMap model, Product product) {
		model.addAttribute("product", new Product());
		return "AdminAddItem";
	}
	
	@RequestMapping(value = "/AddItemForm", method = RequestMethod.POST)
	public String RegisteringForm(ModelMap model,@Valid @ModelAttribute("product") Product product, BindingResult result) {
		System.out.println("Field has any errors : " + result.hasErrors());
		if (result.hasErrors()) {
			return "AdminAddItem";
		}
		productService.save(product);
		return "redirect:/adminDashboard";
	}
	
	@RequestMapping(value = "/adminEditItem/updateItemForm", method = RequestMethod.POST)
	public String updateForm(ModelMap model,@Valid @ModelAttribute("product") Product product, BindingResult result) {
		System.out.println("Field has any errors : " + result.hasErrors());
		if (result.hasErrors()) {
			return "AdminEditItem";
		}
		productService.update(product);
		return "redirect:/adminDashboard";
	}
	
	@RequestMapping(value = "/updateSiteNameForm", method = RequestMethod.POST)
	/*public ModelAndView showWelcome(@RequestParam String fullName) {
		 
		ModelAndView mv = new ModelAndView("welcome");
		mv.addObject("empFullName", fullName);
 
		return mv;
 
	}*/
	public String RegisteringForm(ModelMap model,@Valid @ModelAttribute("siteName") SiteName siteName, BindingResult result) {
		System.out.println("Field has any errors : " + result.hasErrors());
		if (result.hasErrors()) {
			return "AdminSiteName";
		}
		//String abc = siteName.getSiteName();
		System.out.println("******Site Name: "+siteName.getSiteName());
		model.addAttribute("siteName", siteName.getSiteName());
		
		 //session.setAttribute("ans", givenAnswer);
		return "redirect:/adminDashboard";
	}
	
	@RequestMapping(value = "/adminViewItem/{id}", method = RequestMethod.GET)
	public String RegisteringForm(ModelMap model,@PathVariable int id) {
		model.addAttribute("product", productService.getProductById(id));
		return "AdminViewItem";
	}
	
	@RequestMapping(value = "/deleteItem/{id}", method = RequestMethod.GET)
	public String removeUser(@PathVariable("id") int id) {
		productService.delete(id);
		return "redirect:/adminDashboard";
	}
	
	@RequestMapping(value = "/adminEditItem/{id}", method = RequestMethod.GET)
	public String editItem(ModelMap model,@PathVariable int id ) {
		model.addAttribute("product", productService.getProductById(id));
		return "AdminEditItem";
	}
	
	@RequestMapping(value = "/adminSetsiteName", method = RequestMethod.GET)
	public String editItem(ModelMap model) {
		model.addAttribute("siteName", new SiteName());
		return "AdminSiteName";
	}
}
