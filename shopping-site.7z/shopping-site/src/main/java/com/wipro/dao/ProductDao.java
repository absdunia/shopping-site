package com.wipro.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.model.Product;



@Component
public class ProductDao {
	@PersistenceContext
	private EntityManager em;
	
	public List<Product> getAllUsers() {
        TypedQuery<Product> query = em.createQuery(
        		"SELECT p FROM Product p ORDER BY p.id", Product.class);
        return query.getResultList();
    }
	
	@Transactional
	public void delete(int userId) {
		Product user = em.getReference(Product.class, userId);
		em.remove(user);
	}
	
	@Transactional
	public void save(Product product) {
		em.persist(product);
	}


}
