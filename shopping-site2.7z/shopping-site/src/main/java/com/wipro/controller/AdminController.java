package com.wipro.controller;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wipro.model.Product;
import com.wipro.service.ProductService;

@Controller
public class AdminController {
	
	@Autowired
    private ProductService productService;
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/adminDashboard", method = RequestMethod.GET)
	public String home(Model model) {
		
		model.addAttribute("product", productService.getAllUsers() );
		
		return "AdminDashboard";
	}
	
	@RequestMapping(value = "/adminAddItem", method = RequestMethod.GET)
	public String AddItem(ModelMap model, Product product) {
		model.addAttribute("addItem", new Product());
		return "AdminAddItem";
	}
	@RequestMapping(value = "/AddItemForm", method = RequestMethod.POST)
	public String RegisteringForm(ModelMap model,@Valid @ModelAttribute("addItem") Product product, BindingResult result) {
		System.out.println("Field has any errors : " + result.hasErrors());
		if (result.hasErrors()) {
			return "Register";}
		String category = product.getCategory();
		String title = product.getTitle();
		String skuId = product.getSkuId();
		String description = product.getDescription();
	
		System.out.println(" " + category + " " + title + " " + skuId + " " + description );
		model.addAttribute("addItem");
		return "AdminAddItem";
		
	
	}
	

	
}
