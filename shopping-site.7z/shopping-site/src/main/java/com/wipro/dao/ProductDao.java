package com.wipro.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.model.Product;



@Component
public class ProductDao {
	@PersistenceContext
	private EntityManager em;
	
	public List<Product> getAllUsers() {
        TypedQuery<Product> query = em.createQuery(
        		"SELECT p FROM Product p ORDER BY p.id", Product.class);
        return query.getResultList();
    }
	
	public Product getProductById(int prdId) {
        TypedQuery<Product> query = em.createQuery(
        		"SELECT p FROM Product p where p.id = '" + prdId + "'", Product.class);
        return query.getSingleResult();
    }
	
	@Transactional
	public void delete(int prdId) {
		Product user = em.getReference(Product.class, prdId);
		em.remove(user);
	}
	
	@Transactional
	public void save(Product product) {
		em.persist(product);
	}
	@Transactional
	public void update(Product product) {
		Query query = em.createQuery(
        		"UPDATE Product p SET category ='"+ product.getCategory() + "',skuId='"+ product.getSkuId() + "',title ='"+ product.getTitle() + "',description ='"+ product.getDescription() + "',price ='"+ product.getPrice()+ "'WHERE p.skuId = '" + product.getSkuId() + "'");
		int result = query.executeUpdate();
	}

}
