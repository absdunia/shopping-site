package com.wipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.dao.ProductDao;
import com.wipro.model.Product;


@Service
public class ProductService {


	@Autowired
    private ProductDao productDao;
	
	
	public List<Product> getAllUsers() {
		return productDao.getAllUsers();
	}
	public Product getProductById(int id) {
		return productDao.getProductById(id);
	}
	public void save(Product product) {
		productDao.save(product);
	}
	public void update(Product product) {
		productDao.update(product);
	}
	
	public void delete(int userId) {
		productDao.delete(userId);
	}
}
