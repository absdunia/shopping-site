package com.wipro.model;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

public class SiteName {
	
	@Pattern(regexp = "^[a-zA-Z0-9 ]+$",message = "Please enter valid input")
	@Length(min = 4,max = 30, message = "Please enter valid input")	
	private String siteName;

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	
}
